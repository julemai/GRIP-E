# Original File Names

* ml-convlstm-lc_phase_1_objective_1.csv   --> ConvLSTM_withLandcoverNoDEM_2010-2014_20190918-102704.csv
* ml-convlstm-lc_phase_1_objective_2.csv   --> ConvLSTM_withLandcoverNoDEM_2010-2014_20190918-102704.csv
