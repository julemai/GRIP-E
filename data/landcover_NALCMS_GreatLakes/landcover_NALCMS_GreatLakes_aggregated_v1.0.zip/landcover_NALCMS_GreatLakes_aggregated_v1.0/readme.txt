Mapping the land cover data to forcing grids:

(1) Two forcing grids are applied: 
	a. The wfdei_gem_capa forcing grids, 0.125 degree (about 12 km).
	b. The RDRS forcing grids, 10 km.
	
(2) Percentage of 18 land cover types in the NALCMS product are computed in each forcing grid cell.

(3) Variable definitions:
	FID: Order number of grid cells.
	FGID: Index of grid cells in the forcing netCDF file (in the two-dimensional matrix).
	Row: Row number of grid cells in the forcing netCDF file.
	Col: Column number of the grid cells in the forcing netCDF file.
	Gridlat: Lattitude of the grid central point.
	Gridlon: Longitude of the grid central point.
	Area: Area of the grid cells (km2).
	NALCMS_1 to NALCMS_19: Areal percentage (%) of land cover #1 to #19 according to the NALCMS product.
		
(4) Note
	There are some grid cells with very small area. These grids are situated at the four edges of the netCDF domain.
	Since there are no more central points beyond these edges, we cannot get FULL grid polygon for those grid cells. 
	However, these grid cells are chosen as buffer, which will not be used in the hydrological modeling. 
	Thus, these small grids may look weird when checking the grid area info, but will not affect our modeling work.
	
If you have any questions about the land cover mapping results, please contact Hongren Shen: hongren.shen@uwaterloo.ca
	
2020-02-22