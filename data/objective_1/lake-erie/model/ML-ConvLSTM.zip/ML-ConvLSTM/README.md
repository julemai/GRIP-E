# Original File Names

* ml-convlstm_phase_1_objective_1.csv   --> ConvLSTM_withNoLandcoverNoDEM_2010-2014_20190918-134005.csv
* ml-convlstm_phase_1_objective_2.csv   --> ConvLSTM_withNoLandcoverNoDEM_2010-2014_20190918-134005.csv
