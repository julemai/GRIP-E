The eight ASCII files in each folder are data for the variable noted as the folder name for the eight soil layers, from l1 to l8.

These data are clipped from the original GSDE data set for the Great Lakes region. All the soil data processings are based on them.

Silt, sand and clay data definition:
Data unit: % of weight
-9999: No data. Caused by ArcGIS export processing. -9999 exists because these grid cells are out of the data domain.
-100: Missing values. Existed in the original GSDE.

Bulk density data definition:
Data unit: 0.01 g/cm3. Note that the true bulk density = 0.01 * bd 
-9999: No data. Caused by ArcGIS export processing. -9999 exists because these grid cells are out of the data domain.
-999: Missing values. Existed in the original GSDE.