#!/usr/bin/python

import numpy as np, os, datetime
#from pylab import *
#from matplotlib import pyplot
#from matplotlib import gridspec

def ncolsfromtb0(fpathtb0):
    m1 = 0
    m2 = 0
    with open(fpathtb0, 'r') as f:
        for l in f:

            # Continue if not an attribute identified with leading ':'.
            if (l.find(':') != 0):
                continue

            # Attributes.
            m = l.strip().lower().split()
            if (m[0] == ':columnlocationx'):
                m1 = len(m) - 1
            elif (m[0] == ':columnlocationy'):
                m2 = len(m) - 1
            elif (m[0] == ':endheader'):
                break

    # Check the number of columns.
    if (not m1 > 0 or m1 != m2):
        print('ERROR: No columns in %s. m1 = %d, m2 = %d' % (fpathtb0, m1, m2))
        exit()
    else:
        print('INFO: Number of columns in %s is %d' % (fpathtb0, m1))
    return m1

def getattrfromtb0(attrname, fpathtb0):
    attrdat = None
    with open(fpathtb0, 'r') as f:
        for l in f:

            # Continue if not an attribute identified with leading ':'.
            if (l.find(':') != 0):
                continue

            # Attributes.
            m = l.strip().split()
            if (m[0].lower() == attrname.lower()):
                attrdat = ' '.join(m[1:])
                break

    if (attrdat == None):
        print('ERROR: Attribute %s not found in %s' % (attrname, fpathtb0))
    else:
        print('INFO: Attribute %s found in %s' % (attrname, fpathtb0))
    return attrdat

def alldatfromtb0(fpathtb0):
    alldat = None
    z = ''
    with open(fpathtb0, 'r') as f:

        # Continue until end of header.
        while(z != ':endheader'):
            z = f.readline().strip().lower()

        # Read data.
        alldat = f.readlines()
    print('INFO: Found %d records in %s' % (len(alldat), fpathtb0))
    return alldat

def draw_HG(folder, spin, stfl_in, stfl_out, tabscore):

#CSV
#    file = './'+ folder+'/'+stfl_out
#    data = open(file,'r')
#    header = data.readline()
#    datacont = data.readlines()
#    data.close()
#    header = header.split(',')    
#    numgauges = (len(header)-2)/2
#    nbdays = np.size(datacont)
#    dates = []
#    strdates = []
#    Qobs = np.zeros((nbdays,numgauges))
#    Qsim = np.zeros((nbdays,numgauges))
#    statnames = []

#    statfile = stfl_in
#    data2 = open(statfile,'r')
#    datacont2 = data2.readlines()
    n1 = ncolsfromtb0(stfl_in)
    n2 = ncolsfromtb0(stfl_out)
    if (n1 != n2):
        print('ERROR: Mismatch in cols')
        exit()
    else:
        numgauges = n1
    a1 = getattrfromtb0(':StartTime', stfl_in)
    a2 = getattrfromtb0(':StartTime', stfl_out)
    if (a1 != a2):
        print('ERROR: Start time is different between two files, but must be the same for this script')
        exit()
    else:
        startdate = datetime.datetime.strptime(a1, '%Y/%m/%d %H:%M:%S')
    a1 = int(getattrfromtb0(':DeltaT', stfl_in))
    a2 = int(getattrfromtb0(':DeltaT', stfl_out))
    if (a1 != a2):
        print('ERROR: Time-stepping is different between the files')
        exit()
    else:
        deltat = a1
    qm = alldatfromtb0(stfl_in)
    qs = alldatfromtb0(stfl_out)
    if (np.size(qm) != np.size(qs)):
        print('ERROR: Difference record lengths, records must match between the two files')
        exit()
    else:
        nbdays = np.size(qm)
    dates = []
    strdates = []
    Qobs = np.zeros((nbdays,numgauges))
    Qsim = np.zeros((nbdays,numgauges))
    statnames = []

#CSV
#    statline = datacont2[26]
#    statline = statline.split()
#    for i in range(0,numgauges):
#        statnames.append(statline[i+1])
    a1 = getattrfromtb0(':columnname', stfl_in)
    a2 = getattrfromtb0(':columnname', stfl_out)
    if (a1 != a2):
        print('ERROR: Mismatched column names')
        exit()
    else:
        statnames = a1.split()
    
#CSV
#    for i in range(0,nbdays): 
#        line = datacont[i]
#        line = line.split(',')
#        year = str(line[0])
#        day = str(line[1])
#        date = datetime.datetime(int(year),1,1)+datetime.timedelta(int(day)-1)
#        strdate = date.strftime("%Y%m%d")
#        dates.append(date)
#      	strdates.append(strdate)
    
#        for j in range(0,numgauges):
#            obs = float(line[j*2+2])
#            sim = float(line[j*2+3])
#            if (i>0):
#                Qobs[i-1,j] = obs
#            Qsim[i,j] = sim
#            if (i==nbdays-1):
#                Qobs[i, j] = obs    
    date = startdate
    for i in range(0,nbdays): 
        strdate = date.strftime("%Y%m%d")
        dates.append(date)
      	strdates.append(strdate)
    
        Qobs[i,:] = qm[i].split()
        Qsim[i,:] = qs[i].split()
        date = date + datetime.timedelta(hours = deltat)
    print('INFO: Processed %d records' % (i + 1))

    scorefile = './'+folder+'/'+tabscore
    scoref = open(scorefile, 'w')
    scoref.write('gauge NSE SQNSE LNNSE PBIAS \n')
    for j in range(0,numgauges):
#      fig = figure(figsize=(8,5.5))
#      gs = gridspec.GridSpec(2, 1, height_ratios=[1, 3.5])
#      gs.update(left=0.10, right=0.95, bottom=0.15)
#      clf()    
#      ax2=pyplot.subplot(gs[1])
#      maxim = max(max(Qobs[:,j]), max(Qsim[:,j]))
#      ax2.set_ylim([0,maxim])
#      ylabel('Streamflow (m3/s)')
#      plot(dates,Qobs[:,j],'k-',label='observed')    
#      plot(dates,Qsim[:,j],'r-',label='SA-MESH')
#      leg = legend(loc=[0.01,0.90],borderpad=0.1,markerscale=0.1,labelspacing=0,borderaxespad=0.1)
#      for t in leg.get_texts():
#            t.set_fontsize('small')
#      majlabels = [tick.label1 for tick in gca().xaxis.get_major_ticks()]
#      majlines = gca().xaxis.get_gridlines()
#      counter = 0
#      for i in majlabels:
#            i.set_horizontalalignment('right')
#            i.set_verticalalignment('top')
#            i.set_fontsize(10)
#            i.set_rotation(30)

#      ax1=pyplot.subplot(gs[0])
#      ax1.set_xticklabels([], visible=False)
#      ax1.set_yticklabels([], visible=False)
#      ax1.patch.set_visible(False)
#      ax1.set_title("gauge: " + statnames[j],y=0.95,size=13)
#      ax1.axis('off')
     
#      print 'Saving figure ',j+1, ' of ', numgauges
#      savefig('./'+ folder+ '/' + str(statnames[j]) + '.png')
      
      of = Qobs[spin:nbdays, j]
      qf = Qsim[spin:nbdays, j]

      of2 = of[np.where((of[:]>0) & (qf[:]>0))]
      qf2 = qf[np.where((of[:]>0) & (qf[:]>0))]
        
      mynse = nse(qf2,of2)
      mylnse = nse(np.log(qf2), np.log(of2))
      mysqrnse = nse(np.sqrt(qf2),np.sqrt(of2))
      mymae = mae(qf2,of2)
      mybias = pbias(qf2,of2)
      
      
      line = statnames[j] + ' ' + str(mynse) + ' ' + str(mysqrnse) + ' ' + str(mylnse) + ' ' + str(mybias) + '\n'
      scoref.write(line)
      
    scoref.close()
    print('INFO: Output written to %s' % tabscore)
 
    return
    
def nse(sim,obs):
  nse = 1-(sum(pow((sim-obs),2))/sum(pow((obs-(sum(obs)/len(obs))),2)))
  return nse
def nseclim(sim,obs,clim):
  nseclim = 1-(sum(pow((sim-obs),2))/sum(pow((clim-obs),2)))
  return nseclim
def mae(sim,obs):
  return sum(np.fabs(sim-obs))/len(sim)
def rmse(sim,obs):
  return sqrt(sum(pow(sim-obs,2))/len(sim))
def pbias(sim,obs):
  return 100*sum(obs-sim)/sum(obs)
def dmb(sim,obs):
  return sum(sim)/sum(obs)
def pearson(sim,obs):
  avg_x = average(sim)
  avg_y = average(obs)
  diffprod = 0
  xdiff2 = 0
  ydiff2 = 0
  for idx in range(len(sim)):
      xdiff = sim[idx] - avg_x
      ydiff = obs[idx] - avg_y
      diffprod += xdiff * ydiff
      xdiff2 += xdiff * xdiff
      ydiff2 += ydiff * ydiff
  return diffprod / math.sqrt(xdiff2 * ydiff2)    
    
    
#CSV
#draw_HG('.', 365, 'MESH_input_streamflow_Obj1.tb0', 'MESH_output_streamflow_DEFAULT_Obj1.csv', 'CSV_tabscores_DEFAULT_Obj1.txt')
#draw_HG('.', 365, 'MESH_input_streamflow_Obj2.tb0', 'MESH_output_streamflow_DEFAULT_Obj2.csv', 'CSV_tabscores_DEFAULT_Obj2.txt')

#TB0
draw_HG('.', 365, 'MESH_input_streamflow_Obj1.tb0', 'MESH_output_streamflow_DEFAULT_Obj1.tb0', 'TB0_tabscores_DEFAULT_Obj1.txt')
draw_HG('.', 365, 'MESH_input_streamflow_Obj2.tb0', 'MESH_output_streamflow_DEFAULT_Obj2.tb0', 'TB0_tabscores_DEFAULT_Obj2.txt')
