[gl_slope_3sec.txt] is the slope raster exported from ArcGIS.

This slope file is derived from the HydroSHEDS DEM (3sec, ~90m) in ArcGIS. The extent of the domain is the Great Lakes region.

Note that this domain is smaller than either the [wfdei_gem_capa] or [RDRS] forcing domain, since the region out of Great Lakes Basin (i.e. the buffer region in the forcing netCDF) is not necessary for modelling and will consume much more computation resources in slope calculation, thereby not included.

[gl_slope_rdrs_v2_grids.txt] and [gl_slope_wfdei_gem_capa_grids.txt] are the slope at forcing grid-cells upscaled from the 3sec slope. Upscaling method is to calculate the mean of 3sec slope data.

Upscaled slope data definition:
-9999: no data. These grids are the buffer region in forcing netCDF and thus, have no impact on modelling.
=0: slope. There are several 0-value grids within the Great Lakes region, but these grids are ALL out of the 212 catchments extent in our study.
>0: slope. 


Hongren Shen, 
hongren.shen@uwaterloo.ca,
April 11, 2020