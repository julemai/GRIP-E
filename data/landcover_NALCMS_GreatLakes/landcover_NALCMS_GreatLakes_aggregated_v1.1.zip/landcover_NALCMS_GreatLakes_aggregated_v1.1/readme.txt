Mapping the land cover data to forcing grids:
################################################################################################################
2020-04-10 Updates��

To distinguish different versions of the land cover mapping products, we started to name the latest (current) product as v1.1. The previous (untill Feb 22, 2020) product is named as v1.0.

In v1.1 products, a bug has been fixed:

We noticed that in the RDRS forcing file, lattitude and longitude values are defined by a float number with 6 digits. However, in v1.0 product the lat/lon values of some grid 
cells were exported with 5-digit precision. This issue may cause problem when users want to locate those grid cells in the forcing domain.  6-digit values have been used for lat/lon
since v1.1.

We improved the format of the original NALCMS data set for Great Lakes region:

As we also shared the original 30 m NALCMS data set for the Great Lakes region (clipped from the entire NALCMA domain), the previous (in v1.0) one only covered the [wfdei_gem_capa] domain.
In v1.1, we re-clipped the NALCMS data set to make sure it covers both the [wfdei_gem_capa] and [RDRS] domains. Any processing that users want to conduct on this region can start from this
newly-clipped raster.

The NALCMS legend file has been updated, which is consistent with the original NALCMS meta data.

We noticed that it may be toublesome to deal with the original NALCMS raster, which is defined in a projected coordinate system, i.e. using meter unit instead of degree. Thus, we projected
the 30-m raster to a geographic coordinate system, corrsponding to a resolution of 0.00038866585 degree. Please note that due to the irregular transferring from meter to degree, the number of grid
cells are different between these two rasters. This is very normal in raster processing and does not have significant impact on large-scale studies.

Folder [NALCMS_raw_data] contains two files:

(1) [gl_nalcms_30m_raw.tif]: The original NALCMS data set clipped for the Great Lakes region. Projection infomation included.

(2) [gl_nalcms_30m_projected.tif]: The projected NALCMS data set. Resolution 0.00038866585 degree.

################################################################################################################
2020-02-22 Updates:

(1) Two forcing grids are applied: 
	a. The wfdei_gem_capa forcing grids, 0.125 degree (about 12 km).
	b. The RDRS forcing grids, 10 km.
	
(2) Percentage of 18 land cover types in the NALCMS product are computed in each forcing grid cell.

(3) Variable definitions:
	FID: Order number of grid cells.
	FGID: Index of grid cells in the forcing netCDF file (in the two-dimensional matrix).
	Row: Row number of grid cells in the forcing netCDF file.
	Col: Column number of the grid cells in the forcing netCDF file.
	Gridlat: Lattitude of the grid central point.
	Gridlon: Longitude of the grid central point.
	Area: Area of the grid cells (km2).
	NALCMS_1 to NALCMS_19: Areal percentage (%) of land cover #1 to #19 according to the NALCMS product.
		
(4) Note
	There are some grid cells with very small area. These grids are situated at the four edges of the netCDF domain.
	Since there are no more central points beyond these edges, we cannot get FULL grid polygon for those grid cells. 
	However, these grid cells are chosen as buffer, which will not be used in the hydrological modeling. 
	Thus, these small grids may look weird when checking the grid area info, but will not affect our modeling work.
	
If you have any questions about the land cover mapping results, please contact Hongren Shen: hongren.shen@uwaterloo.ca