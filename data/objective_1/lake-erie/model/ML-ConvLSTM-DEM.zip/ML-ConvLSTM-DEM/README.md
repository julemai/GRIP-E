# Original File Names

* ml-convlstm-dem_phase_1_objective_1.csv   --> ConvLSTM_withNoLandcoverButWithDEM_2010-2014_20190918-101932.csv
* ml-convlstm-dem_phase_1_objective_2.csv   --> ConvLSTM_withNoLandcoverButWithDEM_2010-2014_20190918-101932.csv
