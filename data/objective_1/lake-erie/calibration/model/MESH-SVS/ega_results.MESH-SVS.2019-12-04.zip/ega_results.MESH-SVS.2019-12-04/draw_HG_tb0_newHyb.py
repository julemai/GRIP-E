#!/usr/bin/python

# 

import numpy, os, datetime
from pylab import *
from matplotlib import pyplot
from matplotlib import gridspec

def draw_HG(folder, filename, spin):

    file = './'+ folder+'/'+filename
    data = open(file,'r')
    header = data.readline()
    datacont = data.readlines()
    data.close()
    header = header.split(',')    
    numgauges = (len(header)-2)/2
    nbdays = size(datacont)
    dates = []
    strdates = []
    Qobs = zeros((nbdays,numgauges))
    Qsim = zeros((nbdays,numgauges))
    statnames = []

    statfile = 'MESH_input_streamflow.tb0'
    data2 = open(statfile,'r')
    datacont2 = data2.readlines()

    statline = datacont2[26]
    statline = statline.split()
    for i in range(0,numgauges):
        statnames.append(statline[i+1])
    
    for i in range(0,nbdays): 
        line = datacont[i]
        line = line.split(',')
        year = str(line[0])
        day = str(line[1])
        date = datetime.datetime(int(year),1,1)+datetime.timedelta(int(day)-1)
        strdate = date.strftime("%Y%m%d")
        dates.append(date)
      	strdates.append(strdate)
    
        for j in range(0,numgauges):
            obs = float(line[j*2+2])
            sim = float(line[j*2+3])
            if (i>0):
                Qobs[i,j] = obs
            Qsim[i,j] = sim
            if (i==nbdays-1):
                Qobs[i, j] = obs    

    scorefile = './'+folder+'/'+filename.split('/')[-1].split('.')[0]+'_tabscores.txt'
    scoref = open(scorefile, 'w')
    scoref.write('gauge NSE SQNSE LNNSE PBIAS \n')
    for j in range(0,numgauges):
      fig = figure(figsize=(8,5.5))
      gs = gridspec.GridSpec(2, 1, height_ratios=[1, 3.5])
      gs.update(left=0.10, right=0.95, bottom=0.15)
      clf()    
      ax2=pyplot.subplot(gs[1])
      maxim = max(max(Qobs[:,j]), max(Qsim[:,j]))
      ax2.set_ylim([0,maxim])
      ylabel('Streamflow (m3/s)')
      plot(dates,Qobs[:,j],'k-',label='observed')    
      plot(dates,Qsim[:,j],'r-',label='SA-MESH')
      leg = legend(loc=[0.01,0.90],borderpad=0.1,markerscale=0.1,labelspacing=0,borderaxespad=0.1)
      for t in leg.get_texts():
            t.set_fontsize('small')
      majlabels = [tick.label1 for tick in gca().xaxis.get_major_ticks()]
      majlines = gca().xaxis.get_gridlines()
      counter = 0
      for i in majlabels:
            i.set_horizontalalignment('right')
            i.set_verticalalignment('top')
            i.set_fontsize(10)
            i.set_rotation(30)

      ax1=pyplot.subplot(gs[0])
      ax1.set_xticklabels([], visible=False)
      ax1.set_yticklabels([], visible=False)
      ax1.patch.set_visible(False)
      ax1.set_title("gauge: " + statnames[j],y=0.95,size=13)
      ax1.axis('off')
     
      print 'Saving figure ',j+1, ' of ', numgauges
      savefig('./'+ folder+ '/' + str(statnames[j]) + '.png')
      
      of = Qobs[spin:nbdays, j]
      qf = Qsim[spin:nbdays, j]

      of2 = of[numpy.where((of[:]>0) & (qf[:]>0))]
      qf2 = qf[numpy.where((of[:]>0) & (qf[:]>0))]
        
      mynse = nse(qf2,of2)
      mylnse = nse(log(qf2), log(of2))
      mysqrnse = nse(sqrt(qf2),sqrt(of2))
      mymae = mae(qf2,of2)
      mybias = pbias(qf2,of2)
      
      
      line = statnames[j] + ' ' + str(mynse) + ' ' + str(mysqrnse) + ' ' + str(mylnse) + ' ' + str(mybias) + '\n'
      scoref.write(line)
      
    scoref.close()
 
 
    return
    
def nse(sim,obs):
  nse = 1-(sum(pow((sim-obs),2))/sum(pow((obs-(sum(obs)/len(obs))),2)))
  return nse
def nseclim(sim,obs,clim):
  nseclim = 1-(sum(pow((sim-obs),2))/sum(pow((clim-obs),2)))
  return nseclim
def mae(sim,obs):
  return sum(fabs(sim-obs))/len(sim)
def rmse(sim,obs):
  return sqrt(sum(pow(sim-obs,2))/len(sim))
def pbias(sim,obs):
  return 100*sum(obs-sim)/sum(obs)
def dmb(sim,obs):
  return sum(sim)/sum(obs)
def pearson(sim,obs):
  avg_x = average(sim)
  avg_y = average(obs)
  diffprod = 0
  xdiff2 = 0
  ydiff2 = 0
  for idx in range(len(sim)):
      xdiff = sim[idx] - avg_x
      ydiff = obs[idx] - avg_y
      diffprod += xdiff * ydiff
      xdiff2 += xdiff * xdiff
      ydiff2 += ydiff * ydiff
  return diffprod / math.sqrt(xdiff2 * ydiff2)    
    
draw_HG('', 'MESH_output_streamflow_tuned.csv', 365)   # insert subfolder name as first argument if necessary    
draw_HG('', 'MESH_output_streamflow_cal.csv',   365)   # insert subfolder name as first argument if necessary
