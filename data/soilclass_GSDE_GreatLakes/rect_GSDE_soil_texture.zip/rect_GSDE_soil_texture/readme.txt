The eight ASCII files in each folder are data for the variable noted
as the folder name for the eight soil layers, from l1 to l8.


These data are clipped from the original GSDE data set for the Great
Lakes region. All the soil data processings are based on them.


### Silt, sand and clay data definition:
Data unit:   % of weight
-9999:       No data. Caused by ArcGIS export processing. -9999 exists
             because these grid cells are out of the data domain.
-100:        Missing values. Existed in the original GSDE.

### Bulk density data definition:
Data unit:   0.01 g/cm3. Note that the true bulk density = 0.01 * bd 
-9999:       No data. Caused by ArcGIS export processing. -9999 exists
             because these grid cells are out of the data domain.
-999:        Missing values. Existed in the original GSDE.


### Aggregation over 8 layers:
The 8-layers are aggregated based on a weighted average. The weights
we used in the processing are computed based on the GSDE soil depths
of each layer:  
                
    layer 1: 0-4.5 cm
    layer 2: 4.5-9.1 cm
    layer 3: 9.1-16.6 cm
    layer 4: 16.6-28.9 cm
    layer 5: 28.9-49.3 cm
    layer 6: 49.3-82.9 cm
    layer 7: 82.9-138.3 cm
    layer 8: 138.3-229.6 cm

The soil depths for layer1 to layer8 are 4.5, 4.6, 7.5, 12.3, 20.4,
33.6, 55.4, and 91.3 cm, respectively.  

Thus, we can compute the weights of each soil layer by
dividing each layer depth by the total depth, yielding ratios
0.0195993 , 0.02003484, 0.03266551, 0.05357143, 0.08885017,
0.14634146, 0.2412892 , and 0.39764808 respectively.

Files:
  - rect_GSDE_soil_texture.zip --> rect_GSDE_soil_texture_clay_8_layers_avg.txt/nc
  - rect_GSDE_soil_texture.zip --> rect_GSDE_soil_texture_sand_8_layers_avg.txt/nc
  - rect_GSDE_soil_texture.zip --> rect_GSDE_soil_texture_silt_8_layers_avg.txt/nc
