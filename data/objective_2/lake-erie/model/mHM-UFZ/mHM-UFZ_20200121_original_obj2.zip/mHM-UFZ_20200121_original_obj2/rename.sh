#!/bin/bash

set -e

model="mhm-ufz"

if [[ ! -e renamed ]] ; then
    mkdir renamed
fi

for ((ii=1; ii<=46; ii++ )) ; do

    gauge_id=$( grep ^"${ii} " lut_grip_mhm.txt | cut -d ' ' -f 2 )
    echo ${gauge_id}

    found=False

    # find out if objective 1 station
    if [[ ! -z $(grep ",${gauge_id}," ~/Documents/GitHub/GRIP-E/data/objective_1/lake-erie/gauge_info.csv) ]] ; then
	echo "   is objective 1"
	found=True
	#cp ${ii}/output_eval/discharge.nc renamed/${model}_phase_1_objective_1_${gauge_id}.nc
    fi

    # find out if objcetive 2 station
    if [[ ! -z $(grep ",${gauge_id}," ~/Documents/GitHub/GRIP-E/data/objective_2/lake-erie/gauge_info.csv) ]] ; then
	echo "   is objective 2"
	found=True
	cp ${ii}/output_eval/discharge.nc renamed/${model}_phase_1_objective_2_${gauge_id}.nc
    fi

    if [[ ${found} == False ]] ; then
	echo "Station ${gauge_id} is not part of any objective!"
    fi

done

exit 0
