# Original File Names

* ml-convlstm-lc-dem_phase_1_objective_1.csv   --> ConvLSTM_withLandcoverAndDEM_2010-2014_20190918-101035.csv
* ml-convlstm-lc-dem_phase_1_objective_2.csv   --> ConvLSTM_withLandcoverAndDEM_2010-2014_20190918-101035.csv
